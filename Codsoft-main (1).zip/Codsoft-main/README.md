<h1>Codsoft</h1>
<h3>THE INTERNSHIP</h3>
<h4>Codsoft projects</h4>
<h5>TASK 1</h5>             
<h5>TITANIC SURVIVAL PREDICTION</h5>
<p>Use the Titanic dataset to build a model that predicts whether a
passenger on the Titanic survived or not.I have use logistic Regression
and Decision Tree Classsifier and applied Kfloding techniques and cross validation</p><br>
<h5>TASK 2</h5>        
<h5>MOVIE RATING PREDICTION WITH PYTHON</h5>         
<h5>TASK 3</h5>       
<h5>IRIS FLOWER CLASSIFICATION</h5>       
<h5>TASK 4</h5>       
<h5>SALES PREDICTION USING PYTHON</h5>            
<h5>TASK 5</h5>         
<h5>CREDIT CARD FRAUD DETECTION</h5>          
